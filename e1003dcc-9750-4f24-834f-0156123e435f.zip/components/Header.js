import React from 'react';

export default function Header({onClick}) {
  return <div>

  </div>
}